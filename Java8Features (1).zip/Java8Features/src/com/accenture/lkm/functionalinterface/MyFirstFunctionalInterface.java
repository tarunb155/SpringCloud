package com.accenture.lkm.functionalinterface;

/*
 * 1.Only one abstract method is allowed in functional interface.
 * Second abstract methodis not permitted
 * 
 * 2.A functional interface is valid even if the 
 * @FunctionalInterface annotation would be omitted.
 * 
 */
@FunctionalInterface
public interface MyFirstFunctionalInterface {

	public void firstwork();
	
	//public void doSomeWork();
	
}
