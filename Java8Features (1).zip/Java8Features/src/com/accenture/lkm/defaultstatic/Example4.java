package com.accenture.lkm.defaultstatic;
/*
 * Static methods in interfaces
 */

interface MyInterfaceTwo{
	default int sumDefault (int a,int b) {
		return a+b;
	}
	
	//Static method in interface is similar to default except that
	//we cannot override them
	//Static method declaration
    static int sumStatic(int a, int b) {
        return a + b; //simply adds a + b
    }
}
public class Example4 implements MyInterfaceTwo {

	@Override
	public int sumDefault (int a,int b) {
		return a+b-1;
	}
//	@Override
//	static int sumStatic(int a, int b) {
//        return a + b; //simply adds a + b
//    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Example4 obj=new Example4();
		int i=obj.sumDefault(2, 3);
		System.out.println("Default: " + i);
		
		int j=MyInterfaceTwo.sumStatic(3, 4);
		System.out.println("Static: " + j);

		
	}

}
