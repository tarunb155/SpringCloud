package com.accenture.lkm.defaultstatic;

public class Welcome  {

//	@Override
//	public void say() {
//		// TODO Auto-generated method stub
//		
//	}

}
