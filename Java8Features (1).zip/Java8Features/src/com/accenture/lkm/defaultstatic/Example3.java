package com.accenture.lkm.defaultstatic;
/*
 * Scenario3 : Redeclare default methods as abstract ,which force subclass to override it.
 */

interface MyInterfaceOne{
	default void newMethod() {
		System.out.println("Newly added default method:Interface");  
	}
}
abstract class classone implements MyInterfaceOne{
	//default method redeclared as abstract
	public  abstract void newMethod();
}

public class Example3 extends classone {

	@Override
	public void newMethod() {
		// TODO Auto-generated method stub
		System.out.println("Overridden Default Method:Class");
			
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Example3 obj=new Example3();
		obj.newMethod();
	}

}
