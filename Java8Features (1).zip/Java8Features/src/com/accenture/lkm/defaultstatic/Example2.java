package com.accenture.lkm.defaultstatic;
/*
 * Scenario2: class is implementing two interfaces with same default methods
 */
interface Vehicle{
	default void print() {
		System.out.println("I am a vehicle!!!");
	}
	
}
interface FourWheeler{
	default void print() {
		System.out.println("I am a FourWheeler!!!");
	}
}
public class Example2 implements Vehicle,FourWheeler {
	  //First solution is to create an own method that overrides the default implementation.
	public void print() {
			System.out.println("I am a FourWheeler car vehicle!!!");
		}
	 //Second solution is to call the default method of the specified interface using super.
//	@Override
//	public void print() {
//		// TODO Auto-generated method stub
//		FourWheeler.super.print();
//	}
	public static void main(String[] args) {
		Example2 obj=new Example2();
		obj.print();
	}
}
