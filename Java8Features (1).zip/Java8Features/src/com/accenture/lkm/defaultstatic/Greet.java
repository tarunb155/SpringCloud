package com.accenture.lkm.defaultstatic;

public interface Greet {
	
	public void say();
	
	public void hello();

}
