package com.accenture.lkm.defaultstatic;
/*
 * Scenario 1: Create default methods inside interface.
 */
interface MyInterface{
	
	default void newMethod() {
		System.out.println("New default method adder to interface");
	}
}
public class Example1 implements MyInterface{

	/*
	 * We can override default method also to provide more specific implmentation
	 */
	
	public void newMethod() {
		System.out.println("Default method overridden inside class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Example1 obj=new Example1();
		obj.newMethod();
	}

}
