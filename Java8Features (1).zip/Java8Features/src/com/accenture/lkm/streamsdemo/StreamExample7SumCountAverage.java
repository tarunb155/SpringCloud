package com.java8features.streams;

import java.util.Arrays;
import java.util.OptionalDouble;


/**
 * 
 * 
 * @author mani.a.arora
 * 
 * A Reduction Operation is one which allows you to compute a result using all elements
 * present in stream.

 * 
 * Java 8 includes several reduction operations such as sum,count,average which allow to perform Arithmetic 
 * Operations on Stream objects and get numbers as Results.
 *
 */
public class StreamExample7SumCountAverage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int numArray[]={2,4,5,6,7};
		int sum=Arrays.stream(numArray).sum();
		System.out.println("Sum is "+ sum);
		
	    long count=   Arrays.stream(numArray).count();	
        System.out.println("Count is :"+count);
      
        OptionalDouble average=Arrays.stream(numArray).average();
        System.out.println("Average:"+ average.getAsDouble());
	}

}
