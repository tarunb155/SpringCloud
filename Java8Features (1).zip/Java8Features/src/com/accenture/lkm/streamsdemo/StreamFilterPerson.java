package com.accenture.lkm.streamsdemo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamFilterPerson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List <String> nameList=Arrays.asList("Ram","Peter","Pradeep","Steve");
List<String> filteredNameList=nameList.stream().filter(name->name.startsWith("P")).collect(Collectors.toList());

long totalCount=nameList.stream().filter(name->name.startsWith("P")).count();
System.out.println(totalCount);
	
	
	
	
int numArray[]={2,4,5,6,7};
int sum=Arrays.stream(numArray).sum();
System.out.println("Sum is "+ sum);

long count=   Arrays.stream(numArray).count();	
System.out.println("Count is :"+count);
	
	}

}
