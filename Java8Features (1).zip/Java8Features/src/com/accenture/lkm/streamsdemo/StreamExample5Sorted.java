package com.java8features.streams;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 
 * @author mani.a.arora
 * InterMediate Operation: Sorted
 * The Stream.sorted method will return a stream sorted 
 * according to natural order
 *
 */

public class StreamExample5Sorted {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> nameList=new ArrayList<>();
		nameList.add("Amitabh");
		nameList.add("Shekhar");
		nameList.add("Amam");
		nameList.add("Rahul");
		nameList.add("Smrita");
		nameList.add("John");
		nameList.add("Steven");
		
		//Sorted():It sorts the elements of stream using natural ordering. Syntax:list.stream().sorted() 
		System.out.println("---Natural Sorting by Name---");
		nameList.stream().map(String::toUpperCase).sorted().forEach(System.out::println);
		
		System.out.println("---Natural Sorting by Name in reverse order---");
		
		//To reverse the natural ordering Comparator provides reverseOrder() method.
		//Syntax: list.stream().sorted(Comparator.reverseOrder()) 
		nameList.stream().map(String::toUpperCase).sorted(Comparator.reverseOrder()).forEach(System.out::println);
		
		
	}

}
