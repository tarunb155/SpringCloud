package com.accenture.lkm.streamsdemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamCreationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1. Using Stream.of(val1,val2,val3...)
				//of():Returns a sequential ordered stream whose elements 
				       //are the specified values
	     Stream<Integer> stream1=Stream.of(1,2,3,4,5,6,7,8,9,10);
	     stream1.forEach(System.out::println);
	     
	     System.out.println("Character Stream");
	     Stream<Character> streamChar = Stream.of('A','B','C','D');
	     streamChar.forEach(System.out::println); 
	     
	     
	     
	     System.out.println("********Stream Of Array***********");
	     //2.Using Stream.of(arrayOfElements)
	     Integer[] integerArray={1,2,3,4,5,6,7,8,9,10};
	     Stream<Integer> stream2=Stream.of(integerArray);
	     stream2.forEach(System.out::println);
	     
	     //Using Arrays.stream(array)
	     
	     String[] names = {"Lewis Carrol", "H.G. Wells", "Michael Ende",null};
	     Stream<String> stream4 = Arrays.stream(names);
	     stream4.forEach(System.out::println);
	     
	     int[] integers = {1, 4, 6, 2, 6, 3, 2};
	     
	     IntStream stream5=Arrays.stream(integers);
	     stream5.forEach(System.out::println);
	     
	     
	     System.out.println("*********Stream Of Collection**********");
	     //3.Using someList.stream()
	     
	     List <Integer> list=new ArrayList<>();
	     for(int i=1;i<=10;i++){
	    	 list.add(i);
	     }
	     Stream<Integer> stream3=list.stream();
	     stream3.forEach(System.out::println);
	     
	     Stream<Integer> parallelstream=list.parallelStream();
	     parallelstream.forEach(System.out::println);
	     Stream<Integer> parllelStream1=list.parallelStream();
	     parllelStream1.forEachOrdered(System.out::println);
	     
	     
	     // //4.Creating infinite Streams With iterate method 
	     //Stream.iterate()-Returns an infinite Sequential ordered stream
	     
	     Stream<Integer> s=Stream.iterate(2, n->n+3).limit(4);
	     s.forEach(System.out::println);
	     
	   //5.Stream Of Primitives
	     //Interface:IntStream
	     
	     IntStream intStream=IntStream.of(1,2,3,4,5);
	     intStream.forEach(System.out::println);
	     IntStream intStreamRange= IntStream.range(10, 15);
	     intStreamRange.forEach(System.out::println);
	     
	     DoubleStream doubleStream=DoubleStream.of(1.2,3.4,2.3);
	     doubleStream.forEach(System.out::println);
	     
	     
	}

}
