package com.java8features.streams;

import java.util.ArrayList;
import java.util.List;


/**
 * 
 * @author mani.a.arora
 * InterMediate Operation: Map
 * Stream.map() function can be used to perform some operation(function) on all of it�s stream elements
 * A function is a method that accepts an argument and produces a result
 * Names are transformed from lowercase to uppercase
 *
 */
public class StreamExample4Map {
	
	public static void main(String[] args){
	
	List<String> nameList=new ArrayList<>();
	nameList.add("Amitabh");
	nameList.add("Shekhar");
	nameList.add("Amam");
	nameList.add("Rahul");
	nameList.add("Smrita");
	nameList.add("John");
	nameList.add("Steven");
	
	//stream().map() lets you convertor transform an Stream object to another Stream Object.
	nameList.stream().map(String::toUpperCase).forEach(System.out::println);
	
	
	
	}

}
