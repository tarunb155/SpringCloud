package com.accenture.lkm.streamsdemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//To find list of names starting with letter P in the list
public class WithoutStreamFilterPerson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List <String> nameList=Arrays.asList("Ram","Peter","Pradeep","Steve");
		List<String>filteredNamedList	=getFilterOutput(nameList);
		for(String name: filteredNamedList){
			System.out.println(name);
		}
	}

	
	
	private static List<String> getFilterOutput (List<String> nameList){
		List<String> filterNamedList=new ArrayList<>();
		for(String name:nameList){
			if (name.startsWith("P")){
				filterNamedList.add(name);
			}
		}
		return filterNamedList;
	}
}
