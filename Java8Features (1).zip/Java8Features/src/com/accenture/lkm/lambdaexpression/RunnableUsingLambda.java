package com.accenture.lkm.lambdaexpression;

public class RunnableUsingLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//annonymous Class Before Java 8
		Runnable r1=new Runnable() {
			
			public void run() {
				System.out.println("Hello World");
			}
			
		};
		//r1.run();
		Thread t1=new Thread(r1);
		t1.start();
		
		//Java 8 Lambda 
		Runnable r2=()->System.out.println("Hello Runnable!!");
		Thread t2=new Thread(r2);
		t2.start();
		
	}

}
