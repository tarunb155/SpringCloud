package com.accenture.lkm.lambdaexpression;

interface MyFunctionalInterface1{
	public String sayHello();//Method with return type and no parameter.
}
public class Example2LEWithnoParamWithReturnType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		MyFunctionalInterface1 msg=()->"Hello Lambda";
		System.out.println(msg.sayHello());
		
		MyFunctionalInterface1 msg1=()->{return "Hello Lambda";};
		System.out.println(msg1.sayHello());
		
		
		
	}

}
