package com.accenture.lkm.lambdaexpression;


interface MyFunctionalInterface{
	//Method with no parameter and no return type
	public void sayHello();
}
public class Example1LEWithNoParam {
	public static void main(String[] args) {
		
		
		MyFunctionalInterface msg=()->System.out.println("Hello Lambda");
		msg.sayHello();
		
		
	}

}
