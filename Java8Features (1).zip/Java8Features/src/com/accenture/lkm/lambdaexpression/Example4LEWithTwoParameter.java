package com.accenture.lkm.lambdaexpression;

interface StringConcat{
	public String sconcat(String a,String b);
}
interface Addable{
	int add(int a,int b) ;
}
public class Example4LEWithTwoParameter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       ////For multiple parameters, parentheses are required.
		//Optional Type Declaration
		////Curly braces are required to indicate that expression returns a value.
		StringConcat s=(String a,String b)->{
			return a+b;
		};
		System.out.println(s.sconcat("Hello","world"));
		
		
		//Lambda expression without return keyword.
	    //Optional Type Declaration
	    //Curly braces are not required in expression body if the body contains a single statement.
		Addable ref=(a,b)->a+b;
		System.out.println("Sum is "+ ref.add(3, 4));

	}
	  
}
