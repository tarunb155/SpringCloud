package com.accenture.lkm.lambdaexpression;
interface MyFunctionalInterface2{
	
	public String sayHello(String name);
}

@FunctionalInterface
interface SingleParameterInterface{
	
	public int Square(int s);
}

public class Example3LEWithOneParameter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  //with out type declaration		
		//Parameter can be placed within parenthesis and without parenthesis
		MyFunctionalInterface2 msg=	(n)->{
		String str1="Hello";
		String str2=str1+n;
		return str2;
		};
		
		System.out.println(msg.sayHello("Smith"));
		//with type declaration 
	    //Parameter has to be placed in parenthesis
		MyFunctionalInterface2 msg1=(String n)->{return "Hello" + n;};
		System.out.println(msg1.sayHello("Jack"));
		
		
		SingleParameterInterface squa=(s)->s*s;
		System.out.println("Square is : "+ squa.Square(5));
		
		
		
	}

}
