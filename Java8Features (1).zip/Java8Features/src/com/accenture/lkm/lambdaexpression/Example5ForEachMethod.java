package com.accenture.lkm.lambdaexpression;

import java.util.ArrayList;
import java.util.List;

public class Example5ForEachMethod {
	
public static void main(String[] args) {
		List <String> list=new ArrayList<String>();
		list.add("Smith");
		list.add("Jack");
		list.add("Jai");
		//Java 7
		for(String s:list) {
			System.out.println(s);
		}
		/*
		 * forEach method(Consumer Interface)
		 * void accept(T t)
Parameters: This method takes in one parameter:

t� the input argument
Returns: This method does not return any value.
		 */
		list.forEach((n)->System.out.println(n));
		
		
	}

}
