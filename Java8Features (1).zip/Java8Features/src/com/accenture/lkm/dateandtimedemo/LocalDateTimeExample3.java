package com.accenture.lkm.dateandtimedemo;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class LocalDateTimeExample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDateTime dateTime1=LocalDateTime.now();
		System.out.println("Today's date and time is :"+ dateTime1);
		
		/*
		 * year - the year to represent, from MIN_YEAR to MAX_YEAR
		 * month - the month-of-year to represent, from 1 (January) to 12 (December)
		 * dayOfMonth - the day-of-month to represent, from 1 to 31
		 * hour - the hour-of-day to represent, from 0 to 23
		 * minute - the minute-of-hour to represent, from 0 to 59
		 */
		
		LocalDateTime dateTime2=LocalDateTime.of(2017, 8, 1, 23, 54,6,78);
		System.out.println("Localdatetime: "+ dateTime2);
		
		LocalDate date=dateTime1.toLocalDate();
		//Gets the LocalTime part of this date-time
	    LocalTime time=dateTime1.toLocalTime();
	    System.out.println("Localdate: "+ date);
	    System.out.println("Localtime: "+ time);
	    

		//Plus Minus operations
		System.out.println("Date-Time after 10 hours: "+ dateTime1.plusHours(10));
		System.out.println("Date-Time before 2 days: "+dateTime1.minusDays(2));
		
		
		
	}

}
