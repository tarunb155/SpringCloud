package com.accenture.lkm.dateandtimedemo;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class TimeZoneExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ZoneId zone=ZoneId.systemDefault();
		System.out.println(zone);
		
		
		//To print all available zoneIds
		System.out.println(ZoneId.getAvailableZoneIds());
		
		//ZonedDateTimerepresents a date and time with time zone information(Coordinated Universal Time (UTC))
		
		ZonedDateTime  dateAndTimeinIndia = ZonedDateTime.of(LocalDateTime.now(), zone);
		System.out.println("Current date and time in a particular timezone : " + dateAndTimeinIndia);
		
		
		//Define timeZone using timeZonesCodes.
		ZoneId america= ZoneId.of("America/New_York");
		
		ZonedDateTime dateAndTimeInNewYork=ZonedDateTime.of(LocalDateTime.now(), america);
		System.out.println("Current date and time in a particular timezone : " + dateAndTimeInNewYork);  
	}

}
