package com.accenture.lkm.dateandtimedemo;

import java.time.LocalTime;

public class LocalTimeExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalTime time=LocalTime.now();
		System.out.println("Today's time is "+ time);
		/*
		 HourOfDay:0-23
		 MinuteOfHour:0-59
		 SecondOfMinute 0-59
		 NanoOfSecond:0-999999999
		 */
		
		LocalTime time2=LocalTime.of(15,59);
		System.out.println(time2);
		LocalTime time3=LocalTime.of(23, 54, 59,234);
		System.out.println(time3);
		
		
		//Fetching Hour,Minute,Second
		int hour=time.getHour();
		int minute=time.getMinute();
		int second=time.getSecond();
		System.out.println("Hour:"+hour);
		System.out.println("Minute:"+minute);
		System.out.println("Second:"+second);
		
		
 //Plus and Minus Operations
		
		System.out.println("Time after 10 hours: "+time.plusHours(12));
		System.out.println("Time Before 10 hours: "+time.minusHours(10));
		
		System.out.println("Time after 20 mins: "+time.plusMinutes(20));
		System.out.println("Time before 20 mins:"+ time.minusMinutes(20));
	}

}
