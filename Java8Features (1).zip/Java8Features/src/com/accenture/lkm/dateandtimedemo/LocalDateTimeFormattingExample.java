package com.accenture.lkm.dateandtimedemo;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LocalDateTimeFormattingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
		Symbol  Meaning                     Presentation     
		  ------  -------                     ------------      
		   G       era                         text              
		   u       year                        year              
		   y       year-of-era                 year              
		   D       day-of-year                 number            
		   M/L     month-of-year               number/text       
		   d       day-of-month                number            

		   Q/q     quarter-of-year             number/text       
		   Y       week-based-year             year              
		   w       week-of-week-based-year     number            
		   W       week-of-month               number            
		   E       day-of-week                 text              
		   e/c     localized day-of-week       number/text       
		   F       week-of-month               number            

		   a       am-pm-of-day                text              
		   h       clock-hour-of-am-pm (1-12)  number            
		   K       hour-of-am-pm (0-11)        number            
		   k       clock-hour-of-am-pm (1-24)  number            

		   H       hour-of-day (0-23)          number            
		   m       minute-of-hour              number            
		   s       second-of-minute            number            

				 */
		
		
		LocalDate date=LocalDate.now();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd MMM YYYY E");
		String fdate=date.format(formatter);
		System.out.println("Date : "+ date);
		System.out.println("Formatted Date: "+fdate);
		
		LocalDateTime dateTime=LocalDateTime.now();
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-YYYY h:m:s");
		String fDateTime=dateTime.format(format);
		System.out.println("Date Time: "+dateTime);
		System.out.println("Formatted Date Time: "+fDateTime);


	}

}
