package com.accenture.lkm.dateandtimedemo;

import java.time.LocalDate;

public class LocalDateExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDate today=LocalDate.now();
		LocalDate yesterday=today.minusDays(1);
		LocalDate tomorrow=today.plusDays(1);
		System.out.println("Today date: "+today);  
	    System.out.println("Yesterday date: "+yesterday);  
	    System.out.println("Tommorow date: "+tomorrow);  
	    
	    
	    LocalDate date1=LocalDate.of(2018,5,4);
	    System.out.println("Date 1 "+ date1);
	    
	    
	    
	    //current day,month,year
	    int day=today.getDayOfMonth();
	    int month=today.getMonthValue();
	    int year=today.getYear();
	    System.out.printf("Year : %d  Month : %d  day : %d \n", year, month, day);
	    
	    //plus and Minus operations
	    System.out.println("Date after 10 days "+ today.plusDays(10));
	    System.out.println("Date After 3 weeks: "+today.plusWeeks(3));
		System.out.println("Date After 20 months: "+today.plusMonths(20));
		System.out.println("Date After 2 Years: "+today.plusYears(2));
	    
	    
	    
		 System.out.println("Date before 10 days: "+today.minusDays(10));
		   System.out.println("Date before 3 weeks: "+today.minusWeeks(3));
		   System.out.println("Date before 20 months: "+today.minusMonths(20));
		   System.out.println("Date befor 2 Years: "+today.minusYears(2));
		   
		   LocalDate date2= LocalDate.of(2017, 7, 17);//Returns a LocalDate with the specified year,month and day-of-month.
	       System.out.println(date2+" Is Leap Year : "+date2.isLeapYear());
	    
	    
	    
	    
	}

}
