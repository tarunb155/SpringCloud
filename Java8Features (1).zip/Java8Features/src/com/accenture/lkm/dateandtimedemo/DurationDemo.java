package com.accenture.lkm.dateandtimedemo;

import java.time.Duration;
import java.time.LocalTime;

public class DurationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalTime time1 = LocalTime.now();
		System.out.println(time1);
	    LocalTime time2 = time1.plusHours(2);
	    System.out.println(time2);
	    
	  //Measures Period of time  units(hours,minutes and seconds) gap between 2 given time instant.
	    Duration duration = Duration.between(time1, time2);
	    System.out.println("Duration: " + duration);//Duration: PT2H Period time of 2 hours
	    
	}

}
