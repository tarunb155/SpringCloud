package com.accenture.lkm.dateandtimedemo;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class PeriodDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  LocalDate date1 = LocalDate.now();
	      System.out.println("Current date: " + date1);	   

	      LocalDate date2 =date1.plusMonths(1);
	      System.out.println("Next month: " + date2);	
	       //Measures Period of date units(Year,month and days) gap between 2 given date  objects.
	      
	      Period period = Period.between(date1, date2);
	      System.out.println("Period: " + period);	 
	      
	      

	      LocalDate dateOfBirth = LocalDate.of(1970, Month.OCTOBER, 1);
	      Period dobAsPeriod = Period.between(dateOfBirth, LocalDate.now());
	      System.out.println("Period between dob and today's date : "+ dobAsPeriod);
	      System.out.println("You age is " + dobAsPeriod.getYears() + " years , " 
					+ dobAsPeriod.getMonths()
					+ " months and " + dobAsPeriod.getDays() + " days");
	      
	  
	}

}
