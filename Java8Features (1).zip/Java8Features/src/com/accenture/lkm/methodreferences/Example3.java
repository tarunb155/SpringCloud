package com.accenture.lkm.methodreferences;
/*
 * Type3: Reference to an Instance Method of an Arbitrary Object of a Particular Type
 */
interface LowerCase{
	public String Lower(String a);
}
public class Example3 {
	
		public String lowerConvert(String a) {
			return a.toLowerCase();
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //Using Lambda
		Example3 ref=new Example3();
		LowerCase obj1=(a)->ref.lowerConvert(a);
		System.out.println(obj1.Lower("HELLO"));
		
		//Using Method Reference
		//ClassName::instanceMethodName
		LowerCase obj2=String::toLowerCase;
		System.out.println(obj2.Lower("HELLO"));
	}

}
