package com.accenture.lkm.methodreferences;
/*
 * Type 4 : Constructor References
 */
interface Messagable{
	Example4 display(String name);
	
}
public class Example4 {
	
	public Example4(String msg) {
		System.out.println(msg);
	}

	public static void main(String[] args) {
		
		//Lambda Expression
		Messagable ref=(msg)->new Example4(msg);
		ref.display("Hello Lambda");
		
		//Method Reference
		//Classname::new
		
		Messagable ref2=Example4::new;
		  ref2.display("Hello World");
	}
}
