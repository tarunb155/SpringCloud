package com.accenture.lkm.methodreferences;
/*
 * Type 1: Reference to Static Method
 */
interface MyInterface1{
	void display();
}
public class Example1 {
	
	public static void greet() {
		System.out.println("Hello Static method reference");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//using Lambda Expression
		
		MyInterface1 obj=()->Example1.greet();
		obj.display();
		
		//Using Method References
		//classname::staticmethodname
		MyInterface1 obj2=Example1::greet;
		obj2.display();
		
		
	}
}
