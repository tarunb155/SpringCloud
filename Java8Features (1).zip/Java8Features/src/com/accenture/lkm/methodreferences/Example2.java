package com.accenture.lkm.methodreferences;
/*
 * Type 2: Reference to an instance method of a particular object.
 */

interface MyInterface{
	void display();
}
public class Example2 {
	
	public void myMethod() {
		System.out.println("Instance Method ");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Example2 obj=new Example2();
		//Using Lambda eXpression
		MyInterface obj1=()->obj.myMethod();
		obj1.display();
		
		//Method References
		//Objectname::instancemethodname
		MyInterface ref=obj::myMethod;
		ref.display();
	}

}
